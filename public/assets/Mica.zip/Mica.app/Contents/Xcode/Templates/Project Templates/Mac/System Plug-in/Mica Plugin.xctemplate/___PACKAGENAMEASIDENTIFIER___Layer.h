/* ___PACKAGENAME___ - ___FILENAME___

   Copyright ___YEAR___ ___ORGANIZATIONNAME___.
   All rights reserved.

   Created by ___FULLUSERNAME___ on ___DATE___. */

#import <QuartzCore/QuartzCore.h>

@interface ___PACKAGENAMEASIDENTIFIER___Layer : CALayer

@end
