/* ___PACKAGENAME___ - ___FILENAME___

   Copyright ___YEAR___ ___ORGANIZATIONNAME___.
   All rights reserved.

   Created by ___FULLUSERNAME___ on ___DATE___. */

#import "___PACKAGENAMEASIDENTIFIER___Layer.h"

@implementation ___PACKAGENAMEASIDENTIFIER___Layer

@end
