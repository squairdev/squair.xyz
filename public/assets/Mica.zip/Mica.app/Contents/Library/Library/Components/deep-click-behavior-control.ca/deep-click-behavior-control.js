var kBehaviors = [
	"Default",
	"Primary None",
	"Primary Click",
	"Primary Deep Press",
	"Primary Pulse",
	"Low Force Drag",
	"Gas Pedal"
];

function addToLayer() {
	print("addToLayer");
}

Object.defineProperty(this, "behaviorTypeName", {
	get: function() {
		return kBehaviors[layer.touchGestureBehavior]
	},
	set: function(newValue) {
		layer.touchGestureBehavior = kBehaviors.indexOf(newValue);
	}

}) ;
