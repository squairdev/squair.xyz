
// exported properties
var dragThreshold = 2;
var dragX = true;
var dragY = true;
var constrainToParent = false;

// global state
var drag_handler = null;

function eventHandler(e)
{
  Transaction.disableActions = true;

  if (drag_handler)
    {
      drag_handler(e);
    }
  else if (e.type == "mousedown")
    {
      var ep0 = e.position;
      var lp0 = e.positionInLayer(layer.superlayer);
      var sp = layer.position;
      var dragging = false;

      drag_handler = function(e)
        {
	  if (e.type == "mousedragged")
	    {
	      if (!dragging)
		{
		  var dx = e.position.x - ep0.x;
		  var dy = e.position.y - ep0.y;
		  if (Math.max(Math.abs(dx), Math.abs(dy)) > dragThreshold)
		    dragging = true;
		}

	      if (dragging)
		{
		  var ep = e.positionInLayer(layer.superlayer);
		  var p = layer.position;

		  if (dragX)
		    p.x = sp.x + (ep.x - lp0.x);
		  if (dragY)
		    p.y = sp.y + (ep.y - lp0.y);

		  layer.position = p;

		  if (constrainToParent)
		    {
		      var f = layer.frame;
		      var b = layer.superlayer.bounds;

		      if (f.x < b.x)
			p.x -= f.x - b.x;
		      else if (f.x + f.width > b.x + b.width)
			p.x -= (f.x + f.width) - (b.x + b.width);

		      if (f.y < b.y)
			p.y -= f.y - b.y;
		      else if (f.y + f.height > b.y + b.height)
			p.y -= (f.y + f.height) - (b.y + b.height);

		      layer.position = p;
		    }
		}
	    }
	  else
	    drag_handler = null;
	}
    }
}
