
/* Component to apply the screen scale to the layer's contents. */

var oldScale;

function addToLayer ()
{
  /* Can't query screenScale here, we're often called before the window is
     created, and so before the screen is known. */

  layer.setNeedsLayout ();
}

function layoutSublayers ()
{
  var scale = document.screenScale;

  if (scale > 0 && layer.contentsScale != scale)
    {
      oldScale = layer.contentsScale;
      layer.contentsScale = scale;
      layer.setNeedsDisplay();
    }
}

function removeFromLayer ()
{
  if (oldScale)
    {
      layer.contentsScale = oldScale;
      layer.setNeedsDisplay();
      oldScale = undefined;
    }
}
