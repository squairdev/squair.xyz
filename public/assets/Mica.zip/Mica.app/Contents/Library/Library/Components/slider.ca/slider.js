// -*- c-style: gnu -*-

// properties
var sliderType = "vertical";		// horizontal or vertical
var sliderValue = 0;
var sliderMin = 0;
var sliderMax = 1;
var thumbLayer = null;
var sliderTarget = null;
var sliderSignal = "slider";

function layoutSublayers()
{
  if (thumbLayer)
    {
      // FIXME: assumes thumb anchorPosition = .5

      var q = (sliderValue - sliderMin) / (sliderMax - sliderMin);
      var q = Math.min(Math.max(q, 0), 1);

      var r = layer.bounds;
      var p = thumbLayer.position;

      if (sliderType == "horizontal")
	p.x = r.x + q * r.width;
      else
	p.y = r.y + q * r.height;

      thumbLayer.position = p;
    }
}

function updateValue(p)
{
  p = Math.min(Math.max(p, sliderMin), sliderMax);

  if (sliderValue != p)
    {
      sliderValue = p;
      instance.valueChanged("sliderValue");

      layer.setNeedsLayout();

      if (sliderTarget)
	{
	  var args = {sender: instance, value: sliderValue};
	  sliderTarget.dispatchSignal(sliderSignal, args);
	}
    }
}

// dragging state
var mouse_inside = false;
var mouse_down = false;
var mouse_down_location;
var mouse_down_position;

function eventHandler(e)
{
  if (e.type == "mouseover")
    {
      if (e.target == thumbLayer)
	mouse_inside = true;
    }
  else if (e.type == "mouseout")
    {
      if (e.target == thumbLayer)
	mouse_inside = false;
    }
  else if (e.type == "mousedown")
    {
      if (mouse_inside)
	{
	  mouse_down = true;
	  mouse_down_location = e.positionInLayer(layer);
	  mouse_down_position = sliderValue;
	}
      else
	{
	  var r = layer.bounds;
	  var ep = e.positionInLayer(layer);
          var p;

	  if (sliderType == "horizontal")
	    p = (ep.x - r.x) / r.width;
	  else
	    p = (ep.y - r.y) / r.height;

	  p = sliderMin + p * (sliderMax - sliderMin);

	  updateValue(p);
	}
    }
  else if (e.type == "mouseup")
    {
      mouse_down = false;
    }
  else if (e.type == "mousedragged")
    {
      Transaction.disableActions = true;

      if (mouse_down)
	{
	  var r = layer.bounds;
	  var p = sliderValue;
	  var ep = e.positionInLayer(layer);

	  var delta;
	  if (sliderType == "horizontal")
	    delta = (ep.x - mouse_down_location.x) / r.width;
	  else
	    delta = (ep.y - mouse_down_location.y) / r.height;

	  p = mouse_down_position + delta * (sliderMax - sliderMin);

	  updateValue(p);
	}
    }

  var state;
  if (mouse_down)
    state = "active";
  else if (mouse_inside)
    state = "hover";
  else
    state = null;

  document.setState(layer, state);
}

function setSliderValue(arg)
{
  arg = Math.min(Math.max(arg, sliderMin), sliderMax);

  if (sliderValue != arg)
    {
      sliderValue = arg;
      layer.setNeedsLayout();
    }
}

function setSliderMin(arg)
{
  if (sliderMin != arg)
    {
      sliderMin = arg;
      layer.setNeedsLayout();
    }
}

function setSliderMax(arg)
{
  if (sliderMax != arg)
    {
      sliderMax = arg;
      layer.setNeedsLayout();
    }
}
