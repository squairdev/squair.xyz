// -*- c-style: gnu -*-

// properties
var buttonTarget = null;
var buttonSignal = "button";
var buttonType = "push";		// push, toggle
var buttonState = false;

// internal state
var hovering = false;			// mouse over?
var active = false;			// mouse down?

function updateState() {
  var fallback_state = {
    alternate_active: "active",
    alternate_hover: "hover",
    alternate: null,
    active: "hover",
    hover: null
  };

  var state;

  if (active)
    state = buttonState ? "alternate_active" : "active";
  else if (hovering)
    state = buttonState ? "alternate_hover" : "hover";
  else
    state = buttonState ? "alternate" : null;
  
  while (state && !layer.state (state))
    state = fallback_state[state];

  document.setState(layer, state);
}

function eventHandler(e)
{
  if (e.type == "mouseover")
    {
      hovering = true;
    }
  else if (e.type == "mouseout")
    {
      hovering = false;
    }
  else if (e.type == "mousedown")
    {
      active = true;
    }
  else if (e.type == "mouseup")
    {
      active = false;

      if (hovering)
	{
	  if (buttonType == "toggle")
	    {
	      buttonState = !buttonState;
	      instance.valueChanged ("buttonState");
	    }

	  if (buttonTarget)
	    {
	      var args = {sender: instance, value: buttonState};
	      buttonTarget.dispatchSignal(buttonSignal, args);
	    }
	}
    }

  updateState();
}

function setButtonType(arg)
{
  if (buttonType != arg)
    {
      buttonType = arg;
      updateState();
    }
}

function setButtonState(arg)
{
  if (buttonState != arg)
    {
      buttonState = arg;
      updateState();
    }
}
