// -*- c-style: gnu -*-

// properties
var scrollerType = "vertical";		// horizontal or vertical
var scrollerPosition = 0;
var borderSize = new Size (0, 0);
var thumbRatio = .5;
var minimumThumbSize = 10;
var thumbLayer = null;
var scrollerTarget = null;
var scrollerSignal = "scroller";

function layoutSublayers()
{
  if (thumbLayer)
    {
      var border = layer.margin;
      var r = layer.bounds.inset(borderSize.width, borderSize.height);

      var thumb_size, thumb_position;

      if (scrollerType == "horizontal")
	{
	  thumbLayer.cornerRadius
	    = Math.max(0, layer.cornerRadius - borderSize.height);

	  thumb_size = Math.round(r.width * thumbRatio);
	  thumb_size = Math.max(thumb_size, minimumThumbSize);
	  thumb_position = (thumb_size * .5 + (r.width - thumb_size)
			    * scrollerPosition);
	  thumbLayer.position = new Point(r.x + thumb_position,
					  r.y + r.height * .5);
	  thumbLayer.bounds = new Rect(0, 0, thumb_size, r.height);
	}
      else
	{
	  thumbLayer.cornerRadius
	    = Math.max(0, layer.cornerRadius - borderSize.width);

	  thumb_size = Math.round(r.height * thumbRatio);
	  thumb_size = Math.max(thumb_size, minimumThumbSize);
	  thumb_position = (thumb_size * .5 + (r.height - thumb_size)
			    * (1 - scrollerPosition));
	  thumbLayer.position = new Point(r.x + r.width * .5,
					  r.y + thumb_position);
	  thumbLayer.bounds = new Rect(0, 0, r.width, thumb_size);
	}
    }
}

// dragging state
var mouse_inside = false;
var mouse_down = false;
var mouse_down_location;
var mouse_down_position;

function eventHandler(e)
{
  if (e.type == "mouseover")
    {
      if (e.target == thumbLayer)
	mouse_inside = true;
    }
  else if (e.type == "mouseout")
    {
      if (e.target == thumbLayer)
	mouse_inside = false;
    }
  else if (e.type == "mousedown")
    {
      if (mouse_inside)
	{
	  mouse_down = true;
	  mouse_down_location = e.positionInLayer(layer);
	  mouse_down_position = scrollerPosition;
	}
      else
	{
	  // move thumb if to left or right.
	}    
    }
  else if (e.type == "mouseup")
    {
      mouse_down = false;
    }
  else if (e.type == "mousedragged")
    {
      Transaction.disableActions = true;

      if (mouse_down)
	{
	  var r = layer.bounds.inset(borderSize.width, borderSize.height);
	  var tr = thumbLayer.bounds;
	  var p = scrollerPosition;
	  var ep = e.positionInLayer(layer);

	  if (scrollerType == "horizontal")
	    {
	      var dx = (ep.x - mouse_down_location.x) / (r.width - tr.width);
	      p = mouse_down_position + dx;
	    }
	  else
	    {
	      var dy = (ep.y - mouse_down_location.y) / (r.height - tr.height);
	      p = mouse_down_position - dy;
	    }

	  p = Math.min(Math.max(p, 0), 1);

	  if (p != scrollerPosition)
	    {
	      scrollerPosition = p;
	      instance.valueChanged("scrollerPosition");

	      layer.setNeedsLayout();

	      if (scrollerTarget)
		{
		  var args = {sender: instance, value: scrollerPosition};
		  scrollerTarget.dispatchSignal(scrollerSignal, args);
		}
	    }
	}
    }

  var state;
  if (mouse_down)
    state = "active";
  else if (mouse_inside)
    state = "hover";
  else
    state = null;

  document.setState(layer, state);
}

function setThumbRatio(arg)
{
  if (thumbRatio != arg)
    {
      thumbRatio = arg;
      layer.setNeedsLayout();
    }
}

function setScrollerPosition(arg)
{
  arg = Math.min(Math.max(arg, 0), 1);

  if (scrollerPosition != arg)
    {
      scrollerPosition = arg;
      layer.setNeedsLayout();
    }
}

function setMinimumThumbSize(arg)
{
  if (minimumThumbSize != arg)
    {
      minimumThumbSize = arg;
      layer.setNeedsLayout();
    }
}

function setBorderSize(arg)
{
  arg.width = Math.max(arg.width, 0);
  arg.height = Math.max(arg.height, 0);

  if (borderSize != arg)
    {
      borderSize = arg;
      layer.setNeedsLayout();
    }
}
