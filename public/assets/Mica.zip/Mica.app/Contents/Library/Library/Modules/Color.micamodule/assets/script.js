/*
 Built-in variables (don't uncomment, for documentation only).

 var layer;     -- this script's layer
 var document;  -- this script's document
 var system;    -- Properties about the current system. Local to each context
                   (version, build, productType, model, platform, appVersion)
 var instance;  -- ScriptObject (Properties: inspector)

 Script initialization functions:
 
 init(): Initialize variables and state. This will be called when a script is loaded 
         or updated. Do not depend on the ordering. Do not assume that all other scripts
         have been initialized.

 ready(): Called after all scripts are initialized. If a single script is updated,
          only that script will have ready() called. Do not depend on the ordering.
 */


// ----------------------------------------------------------------------------
// Properties
// ----------------------------------------------------------------------------

let properties = {

  color: new Color("1 0 0"),
  name: "red",
  number: 42,
};

// ----------------------------------------------------------------------------
// Initialization
// ----------------------------------------------------------------------------

function init() {

  print(instance.name + ": init()");
}

function ready() {

  print(instance.name + ": ready()");
  applyBackgroundColor();
}

// ----------------------------------------------------------------------------
// Inspector UI
// ----------------------------------------------------------------------------

function updateInspectorView(inspector, proposedInspectorItems) {

  const inspectorItems = [

    new InspectorItem({title: "Main", subitems: [
      new InspectorItem({title: "Color", key: "color", type: "color"}),
      new InspectorItem({title: "Name", key: "colorName", type: "string"})
    ]}),

    new InspectorItem({title: "Secondary", subitems: [
      new InspectorItem({title: "Number", key: "number", type: "number"})
    ]})

  ];

  return inspectorItems;
}

// ----------------------------------------------------------------------------
// Property Storage
// ----------------------------------------------------------------------------

function getPropertyValue(key) {

  return properties[key];
}

function setPropertyValue(key, value) {

  properties[key] = value;

  // If we changed the name, update the color
  //
  if (key == "colorName") {
    properties.color = new Color(value);
  }

  applyBackgroundColor();
}

function initializePropertyValue(key, value) {

  properties[key] = value;
}

function storePropertyValues(storage) {

  for (const [key, value] of Object.entries(properties)) {
    storage.setItem(key, value)
  }
}

// ----------------------------------------------------------------------------
// Helper
// ----------------------------------------------------------------------------

function applyBackgroundColor() {

  layer.backgroundColor = properties.color;
}
