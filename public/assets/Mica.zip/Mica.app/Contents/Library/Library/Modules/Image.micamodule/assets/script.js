/*
 Built-in variables (don't uncomment, for documentation only).

 var layer;     -- this script's layer
 var document;  -- this script's document
 var system;    -- Properties about the current system. Local to each context
                   (version, build, productType, model, platform, appVersion)
 var instance;  -- ScriptObject (Properties: inspector)

 Script initialization functions:
 
 init(): Initialize variables and state. This will be called when a script is loaded 
         or updated. Do not depend on the ordering. Do not assume that all other scripts
         have been initialized.

 ready(): Called after all scripts are initialized. If a single script is updated,
          only that script will have ready() called. Do not depend on the ordering.
 */

// ----------------------------------------------------------------------------
// Initialization
// ----------------------------------------------------------------------------

function init() {

  print("Image Module init().");
}

function ready() {

  print("Image Module ready().")
  applyImage();
}

// ----------------------------------------------------------------------------
// Property Changes
// ----------------------------------------------------------------------------

function propertyValueChanged(key) 
{
  // If we changed the myString, update the layer's contents
  if (key == "imageName") {

    applyImage();
  }
}

// ----------------------------------------------------------------------------
// Module Lifecycle
// ----------------------------------------------------------------------------

function addToLayer() {

  applyImage();
}

function removeFromLayer() {

  layer.contents = null;
}

// ----------------------------------------------------------------------------
// Helper
// ----------------------------------------------------------------------------

// Helper function to load and set the layer's 
// contents based on the selected image name

function applyImage() {

  let imageName = instance.properties.imageName;
  let imageAsset = instance.loadAsset(imageName);

  if (imageAsset) {

    layer.contents = imageAsset;
    layer.contentsGravity = "resizeAspect";
  }
}
