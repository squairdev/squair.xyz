/*
 Built-in variables (don't uncomment, for documentation only).

 var layer;     -- this script's layer
 var document;  -- this script's document
 var system;    -- Properties about the current system. Local to each context
                   (version, build, productType, model, platform, appVersion)
 var instance;  -- ScriptObject (Properties: inspector)

 Script initialization functions:
 
 init(): Initialize variables and state. This will be called when a script is loaded 
         or updated. Do not depend on the ordering. Do not assume that all other scripts
         have been initialized.

 ready(): Called after all scripts are initialized. If a single script is updated,
          only that script will have ready() called. Do not depend on the ordering.
 */

// ----------------------------------------------------------------------------
// Properties
// ----------------------------------------------------------------------------

// Public properties that show in the inspector are declared in module.json.
// You can read and write to them via `instance.properties.<propertyName>`.

// Internal Properties
//
let internalProperties = {

  hovering: false, // mouseover
  active:   false, // mousedown
};

// ----------------------------------------------------------------------------
// Initialization
// ----------------------------------------------------------------------------

function init() 
{
}

function ready() 
{
}

// ----------------------------------------------------------------------------
// Events
// ----------------------------------------------------------------------------

function eventHandler(event) 
{  
  if (event.type == "mouseover") 
  {
    internalProperties.hovering = true;
  }
  else if (event.type == "mouseout") 
  {
    internalProperties.hovering = false;
  }
  else if (event.type == "mousedown") 
  {
    internalProperties.active = true;
  }
  else if (event.type == "mouseup") 
  { 
    internalProperties.active = false;

    if (internalProperties.hovering) 
    {
      print(`Type: ${instance.properties.buttonType}`)
      if (instance.properties.buttonType == "toggle")
      {
        print(`Toggle: ${instance.properties.buttonType}`)
        instance.properties.buttonState = !instance.properties.buttonState;
      }

      if (instance.properties.buttonTarget)
      {
        const state = instance.properties.buttonState;
        const target = instance.properties.buttonTarget;
        const signal = instance.properties.buttonSignal;
        const args = { sender: instance, value: state };

        if (target && signal) 
        {
          target.dispatchSignal(signal, args);
        }
      }
    }
  }

  updateLayerState();
}

// ----------------------------------------------------------------------------
// Property Changes
// ----------------------------------------------------------------------------

function propertyValueChanged(key) 
{
  if (key == "buttonType" || key == "buttonState") 
  {
    updateLayerState();
  }
}

// ----------------------------------------------------------------------------
// Helper
// ----------------------------------------------------------------------------

function updateLayerState()
{
  let layerState = null;
  const buttonState = instance.properties.buttonState;
  
  if (internalProperties.active)
  {
    layerState = buttonState ? "alternate_active" : "active";
  }
  else if (internalProperties.hovering)
  {
    layerState = buttonState ? "alternate_hover" : "hover";
  }
  else
  {
    layerState = buttonState ? "alternate" : null;
  }
  
  const fallbackState = {
    alternate_active: "active",
    alternate_hover: "hover",
    alternate: null,
    active: "hover",
    hover: null
  };
  
  // Fallback to more genral states if the layer doesn't have the chosen state
  //
  while (layerState && !layer.state(layerState))
  {
    layerState = fallbackState[layerState];
  }
  
  document.setState(layer, layerState);
}
