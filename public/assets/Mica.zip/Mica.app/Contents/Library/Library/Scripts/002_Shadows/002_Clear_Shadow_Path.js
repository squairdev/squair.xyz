
/* Sets the shadowPath of all selected layers to null. */

var layers = document.selectedLayers;

for (var i = 0; i < layers.length; i++) {
    var layer = layers[i];
    document.setValue (layer, "shadowPath", null);
}
