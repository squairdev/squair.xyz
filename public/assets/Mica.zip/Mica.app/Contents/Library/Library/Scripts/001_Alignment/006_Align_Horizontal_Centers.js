
layers = document.selectedLayers;

if (layers && layers.length > 1) {
    x = layers[0].position.x;
    for (i = 1; i < layers.length; i++) {
	p = layers[i].position;
	p.x = x;
	document.setValue (layers[i], "position", p);
    }
}
