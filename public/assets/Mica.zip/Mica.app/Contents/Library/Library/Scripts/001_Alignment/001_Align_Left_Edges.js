
layers = document.selectedLayers;

if (layers && layers.length > 1) {
    minx = layers[0].frame.x;
    for (i = 1; i < layers.length; i++) {
	r = layers[i].frame;
	r.x = minx;
	document.setValue (layers[i], "frame", r);
    }
}
