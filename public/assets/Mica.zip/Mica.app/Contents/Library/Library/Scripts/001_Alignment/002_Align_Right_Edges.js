
layers = document.selectedLayers;

if (layers && layers.length > 1) {
    maxx = layers[0].frame.x + layers[0].frame.width;
    for (i = 1; i < layers.length; i++) {
	r = layers[i].frame;
	r.x = maxx - r.width;
	document.setValue (layers[i], "frame", r);
    }
}
