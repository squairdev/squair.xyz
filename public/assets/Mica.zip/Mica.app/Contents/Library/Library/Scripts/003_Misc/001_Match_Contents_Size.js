
layers = document.selectedLayers;

for (i = 0; i < layers.length; i++) {
  var image = layers[i].contents;
  if (image == null)
      continue;
  var width = image.width;
  var height = image.height;
  if (width && height) {
      var r = layers[i].bounds;
      r.width = width;
      r.height = height;
      document.setValue (layers[i], "bounds", r);
    }
}
