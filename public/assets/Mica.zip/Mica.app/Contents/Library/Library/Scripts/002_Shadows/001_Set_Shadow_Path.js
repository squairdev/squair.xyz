
/* Sets the shadowPath of all selected layers to their bounds. */

var layers = document.selectedLayers;

for (var i = 0; i < layers.length; i++) {
    var layer = layers[i];
    var path = new Path ();
    var radius = layer.cornerRadius;
    if (radius > 0)
	path.roundedRect (layer.bounds, radius, radius);
    else
	path.rect (layer.bounds);
    document.setValue (layer, "shadowPath", path);
}
