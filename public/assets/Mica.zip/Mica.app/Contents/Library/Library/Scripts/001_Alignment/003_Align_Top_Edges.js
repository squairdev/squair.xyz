
layers = document.selectedLayers;

if (layers && layers.length > 1) {
    maxy = layers[0].frame.y + layers[0].frame.height;
    for (i = 1; i < layers.length; i++) {
	r = layers[i].frame;
	r.y = maxy - r.height;
	document.setValue (layers[i], "frame", r);
    }
}
