
layers = document.selectedLayers;

if (layers && layers.length > 1) {
    miny = layers[0].frame.y;
    for (i = 1; i < layers.length; i++) {
	r = layers[i].frame;
	r.y = miny;
	document.setValue (layers[i], "frame", r);
    }
}
