
layers = document.selectedLayers;

if (layers && layers.length > 1) {
    y = layers[0].position.y;
    for (i = 1; i < layers.length; i++) {
	p = layers[i].position;
	p.y = y;
	document.setValue (layers[i], "position", p);
    }
}
