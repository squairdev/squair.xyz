/*
Built-in variables (don't uncomment, for documentation only).

var layer;      -- this script's layer
var document; -- this script's document
var system;    -- Properties about the current system. Local to each context
                 (version, build, productType, model, platform, appVersion)

Script initialization functions:

init(): Initialize variables and state. This will be called when a script is loaded 
       or updated. Do not depend on the ordering. Do not assume that all other scripts
       have been initialized.

ready(): Called after all scripts are initialized. If a single script is updated,
        only that script will have ready() called. Do not depend on the ordering.
*/

let intervalRef = 0;

let properties = {
  baz: 0.5,
  foo: "foobar",
  choice: "One",
  range: 5,
  range2: 4,
  check: true,
  array: ["one", "two", "three"],
};

let objs = {
  color: new Color("1 0 0"),
  point: new Point(1, 2),
  timing: new TimingFunction("easeIn"),
  colorMatrix: new ColorMatrix(),
};

var otherOne = 99;
var otherTwo = "blah";
var actionButton = 0;

// Keep track of the inspector that was passed into the updateInspectorView
var inspector = null;

// Special property for inspector tab title
var inspectorTabTitle = "I'm Scripty!";

function init() {
  print("init(): " + layer.name);
}

function ready() {
  print("ready(): " + layer.name);
}

function updateInspectorView(inspector) {
  // Keep track of inspector
  this.inspector = inspector;

  // Return an array of groups of properties
  let groups = [];
  let defs = [];
  let items = [];

  // Definitions for InspectorItem()
  defs.push({"title": "Check", "key": "properties.check", "type": "number", "subtype": "bool"});
  defs.push({"title": "Range", "key": "properties.range", "type": "number", "min": 0.5, "max": 8});
  defs.push({"title": "Increment", "key": "properties.range2", "type": "number", "increment": 0.5});

  defs.push({"title": "Color", "key": "objs.color", "type": "color"});
  defs.push({"title": "Point", "key": "objs.point", "type": "point"});
  defs.push({"title": "Timing", "key": "objs.timing", "type": "timing"});
  defs.push({"title": "Matrix", "key": "objs.colorMatrix", "type": "colorMatrix"});

  defs.push({"title": "Bar", "key": "properties.baz", "type": "number", "subtype": "percentage"});
  defs.push({"title": "Foo", "key": "properties.foo", "type": "string"});
  defs.push({"title": "Choice", "key": "properties.choice", "type": "string", "subtype": "enum",
    "enumNames": ["One", "Both"]});
  defs.push({"title": "Perform Action", "key": "actionButton", "type": "integer", "subtype":"button"});
  defs.push({"title": "Array", "key": "properties.array", "type": "array", "subtype": "string"});

  for (idx in defs) {
    items.push(new InspectorItem(defs[idx]));
  }

  groups.push(new InspectorItem({"title": "Group One", "subitems": items}));

  if (properties.choice == "Both") {

    defs = [];
    items = [];
    defs.push({"title": "Other1", "key": "otherOne", "type": "number"});
    defs.push({"title": "Other2", "key": "otherTwo", "type": "string"});

    for (idx in defs) {
      items.push(new InspectorItem(defs[idx]));
    }

    groups.push(new InspectorItem({"title": "Group Two", "subitems": items}));
  }

  return groups;
}

function keyFromKeyPath(prefix, keyPath) {
  return keyPath.startsWith(prefix) ? keyPath.substr(prefix.length) : "";
}

function extractPropertyKey(key) {
  return keyFromKeyPath("properties.", key);
}

function extractObjectKey(key) {
  return keyFromKeyPath("objs.", key);
}

function getPropertyValue(key) {
  let propKey = extractPropertyKey(key);
  let objsKey = extractObjectKey(key);

  if (propKey.length > 0) {
   return properties[propKey];
  }

  if (objsKey.length > 0) {
    return objs[objsKey];
  }

  return this[key];
}

function setPropertyValue(key, value) {
  let propKey = extractPropertyKey(key);
  let objsKey = extractObjectKey(key);

  if (propKey.length > 0) {
    properties[propKey] = value;

    // If we changed the choice, reload
    if (propKey == "choice") {
      this.inspector.reloadView();
    }
  } else if (objsKey.length > 0) {
    objs[objsKey] = value;
  } else {
    this[key] = value;
  }

}
