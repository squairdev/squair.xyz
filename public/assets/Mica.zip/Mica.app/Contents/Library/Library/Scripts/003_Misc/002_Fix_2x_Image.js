
layers = document.selectedLayers;

for (i = 0; i < layers.length; i++) {
  var image = layers[i].contents;
  if (image == null)
      continue;
  var width = image.width;
  var height = image.height;
  if (width && height) {
      var r = layers[i].bounds;
      r.width = r.width / 2;
      r.height = r.height / 2;
      document.setValue (layers[i], "bounds", r);
      var scale = layers[i].contentsScale * 2;
      document.setValue (layers[i], "contentsScale", scale);
    }
}
